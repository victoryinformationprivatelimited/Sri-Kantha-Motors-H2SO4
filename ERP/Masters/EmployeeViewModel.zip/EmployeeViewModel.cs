﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ERP.ERPService;
using ERP.AdditionalWindows;
using ERP.Masters;
using System.ComponentModel;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using ERP.Reports;
using System.Windows.Threading;
using ERP.Attendance.Master_Details;
using ERP.Medical;

namespace ERP
{
    class EmployeeViewModel : ViewModelBase, IDataErrorInfo
    {
        #region Service Client

        private ERPServiceClient serviceClient = new ERPServiceClient();

        #endregion Service Client

        #region Constructor

        private Task T;

        public EmployeeViewModel()
        {
            scale();
            if (clsSecurity.GetPermissionForView(clsConfig.GetViewModelId(Viewmodels.Employee), clsSecurity.loggedUser.user_id))
            {
                DispatcherTimer tick = new DispatcherTimer();
                int count = 0;
                tick.Interval = new TimeSpan(0, 0, 0, 0, 300);
                tick.Start();
                tick.Tick += (s, e) => { count++; if (count == 2) { loader.Start(); tick.Stop(); } };
                loader = new DispatcherTimer();
                loader.Tick += dis_Tick;
                loader.Interval = new TimeSpan(0, 0, 0, 0, 5);

                isBusy = true;
                busyGridVisibility = Visibility.Visible;

                T = new Task(() =>
                {
                    path = "C:\\H2SO4\\LocalEmployee\\";

                    refreshEmployees();

                    SelectionItems.Add("Employee No");
                    SelectionItems.Add("First Name");
                    SelectionItems.Add("Last Name");
                    SelectionItems.Add("Section");
                    SelectionItems.Add("Department");
                    SelectionItems.Add("Designation");
                    SelectionItems.Add("Grade");

                    EPFList.Add("Extg.");
                    EPFList.Add("New");
                    EPFList.Add("Vacated");

                    refresh();
                    refreshEpfStatus();

                });
            }
            else
            {
                clsMessages.setMessage(Properties.Resources.NoPermissionForView);
            }

        }

        #endregion Constructor

        DispatcherTimer loader;

        string path;

        private void dis_Tick(object sender, EventArgs e)
        {
            Progress++;

            if (Progress == 20)
            {
                T.Start();
                loader.Stop();
                loader.Start();
            }
            if (Progress == 50)
            {
                loader.Stop();
                loader.Start();
            }
            if (Progress == 80)
            {
                T.ContinueWith(antecedent => after(), TaskScheduler.FromCurrentSynchronizationContext());
                loader.Stop();
                loader.Start();
            }
            if (Progress == 100)
            {
                //T.ContinueWith(antecedent => after(), TaskScheduler.FromCurrentSynchronizationContext());
                loader.Stop();
                Progress = 0;
            }
        }

        #region Properties

        private int _progress;
        public int Progress
        {
            get { return _progress; }
            set { _progress = value; OnPropertyChanged("Progress"); }
        }

        private IEnumerable<EmployeeSumarryView> _AllEmployees;
        public IEnumerable<EmployeeSumarryView> AllEmployees
        {
            get { return _AllEmployees; }
            set
            {
                _AllEmployees = value;
                this.OnPropertyChanged("AllEmployees");
            }
        }

        private IEnumerable<EmployeeSumarryView> _AllEmployeesSorted;
        public IEnumerable<EmployeeSumarryView> AllEmployeesSorted
        {
            get { return _AllEmployeesSorted; }
            set
            {
                _AllEmployeesSorted = value;
                this.OnPropertyChanged("AllEmployeesSorted");
            }
        }

        private EmployeeSumarryView _CurrentEmployee;
        public EmployeeSumarryView CurrentEmployee
        {
            get { return _CurrentEmployee; }
            set
            {
                _CurrentEmployee = value;
                this.OnPropertyChanged("CurrentEmployee");

                if (CurrentEmployee != null && CurrentEmployee.employee_id != Guid.Empty && CurrentEmployee.isdelete == false)
                {
                    #region Image Save

                    this.Image = null;
                    ImagePath = null;
                    if (CurrentEmployee.image != null)
                    {
                        this.EmployeeImagePath = CurrentEmployee.image;
                        this.ImagePath = CurrentEmployee.image;
                    }
                    #endregion

                    #region Member

                    if (EPFList != null)
                        try
                        {
                            CurrentEPFList = null;
                            dtl_member_status m1;
                            m1 = MemberStaus.Where(c => c.employee_id == CurrentEmployee.employee_id).FirstOrDefault();
                            if (m1 != null)
                            {
                                if (m1.member_status.Equals("E"))
                                    CurrentEPFList = "Extg.";
                                else if (m1.member_status.Equals("N"))
                                    CurrentEPFList = "New";
                                else if (m1.member_status.Equals("V"))
                                    CurrentEPFList = "Vacated";
                            }
                        }
                        catch (Exception)
                        {
                            CurrentEPFList = null;
                        }

                    #endregion

                    this.Name = CurrentEmployee.initials + " " + CurrentEmployee.first_name + " " + CurrentEmployee.second_name;

                    EmployeeNo = CurrentEmployee.emp_id;
                    FirstName = CurrentEmployee.first_name;
                    Surname = CurrentEmployee.surname;
                    NIC = CurrentEmployee.nic;
                    Birthday = CurrentEmployee.birthday;
                    Address = CurrentEmployee.address_01;
                    Mobile = CurrentEmployee.mobile;

                    loadGrid();
                }

                else
                {
                    Name = null;
                    EmployeeNo = null;
                    FirstName = null;
                    Surname = null;
                    NIC = null;
                    Birthday = null;
                    Address = null;
                    Mobile = null;

                    ImagePath = null;
                }
            }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; this.OnPropertyChanged("Name"); }
        }

        private IEnumerable<z_Title> _title;
        public IEnumerable<z_Title> Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged("Title"); }
        }

        private z_Title _currentTitle;
        public z_Title CurrentTitle
        {
            get { return _currentTitle; }
            set { _currentTitle = value; OnPropertyChanged("CurrentTitle"); }
        }

        private IEnumerable<z_Religen> _Religen;
        public IEnumerable<z_Religen> Religen
        {
            get { return _Religen; }
            set { _Religen = value; this.OnPropertyChanged("Religen"); }
        }

        private z_Religen _CurrentReligen;
        public z_Religen CurrentReligen
        {
            get { return _CurrentReligen; }
            set { _CurrentReligen = value; this.OnPropertyChanged("CurrentReligen"); }
        }

        #region Genders list
        private IEnumerable<z_Gender> _Genders;
        public IEnumerable<z_Gender> Genders
        {
            get { return _Genders; }
            set { _Genders = value; this.OnPropertyChanged("Genders"); }
        }
        #endregion

        #region Current Gender
        private z_Gender _CurrentGender;
        public z_Gender CurrentGender
        {
            get { return _CurrentGender; }
            set { _CurrentGender = value; this.OnPropertyChanged("CurrentGender"); }

        }
        #endregion

        #region Cities List
        private IEnumerable<z_City> _Citys;
        public IEnumerable<z_City> Citys
        {
            get { return _Citys; }
            set { _Citys = value; this.OnPropertyChanged("Citys"); }
        }
        #endregion

        #region Current City
        private z_City _CurrentCity;
        public z_City CurrentCity
        {
            get { return _CurrentCity; }
            set
            {
                _CurrentCity = value;
                this.OnPropertyChanged("CurrentCity");
                refreshTowns();
            }
        }
        #endregion

        #region Towns List
        private IEnumerable<z_Town> _Towns;
        public IEnumerable<z_Town> Towns
        {
            get { return _Towns; }
            set { _Towns = value; this.OnPropertyChanged("Towns"); }
        }
        #endregion

        #region Current Town
        private z_Town _CurrentTown;
        public z_Town CurrentTown
        {
            get { return _CurrentTown; }
            set { _CurrentTown = value; this.OnPropertyChanged("CurrentTown"); }
        }
        #endregion

        #region Civel State List
        private IEnumerable<z_CivilState> _SivelStates;
        public IEnumerable<z_CivilState> SivelStates
        {
            get { return _SivelStates; }
            set { _SivelStates = value; this.OnPropertyChanged("SivelStates"); }
        }
        #endregion

        #region Current Civil Status
        private z_CivilState _CurrentCivilStatus;
        public z_CivilState CurrentCivilStatus
        {
            get { return _CurrentCivilStatus; }
            set { _CurrentCivilStatus = value; this.OnPropertyChanged("CurrentCivilStatus"); }
        }
        #endregion

        #region Departments List
        private IEnumerable<z_Department> _Departments;
        public IEnumerable<z_Department> Departments
        {
            get { return _Departments; }
            set { _Departments = value; this.OnPropertyChanged("Departments"); }
        }
        #endregion

        #region Current Department
        private z_Department _CurrentDepartment;
        public z_Department CurrentDepartment
        {
            get { return _CurrentDepartment; }
            set
            {
                _CurrentDepartment = value;
                this.OnPropertyChanged("CurrentDepartment");
                // reafreshSection();
            }
        }
        #endregion

        #region Designations List
        private IEnumerable<z_Designation> _Designations;
        public IEnumerable<z_Designation> Designation
        {
            get { return _Designations; }
            set { _Designations = value; this.OnPropertyChanged("Designation"); }
        }
        #endregion

        #region Current Designation
        private z_Designation _CurrentDesignation;
        public z_Designation CurrentDesignation
        {
            get { return _CurrentDesignation; }
            set { _CurrentDesignation = value; this.OnPropertyChanged("CurrentDesignation"); }
        }
        #endregion

        #region Sections List
        private IEnumerable<z_Section> _Sections;
        public IEnumerable<z_Section> Sections
        {
            get { return _Sections; }
            set { _Sections = value; this.OnPropertyChanged("Sections"); }
        }
        #endregion

        #region Current Section
        private z_Section _CurrentSection;
        public z_Section CurrentSection
        {
            get { return _CurrentSection; }
            set { _CurrentSection = value; this.OnPropertyChanged("CurrentSection"); }
        }
        #endregion

        #region Grades List
        private IEnumerable<z_Grade> _Grades;
        public IEnumerable<z_Grade> Grades
        {
            get { return _Grades; }
            set { _Grades = value; this.OnPropertyChanged("Grades"); }
        }
        #endregion

        #region Current Grade
        private z_Grade _CurrentGrade;
        public z_Grade CurrentGrade
        {
            get { return _CurrentGrade; }
            set { _CurrentGrade = value; this.OnPropertyChanged("CurrentGrade"); }
        }
        #endregion

        #region Detail Employee View List
        private IEnumerable<EmployeeSumarryView> _DetailEmployees;
        public IEnumerable<EmployeeSumarryView> DetailEmployees
        {
            get { return _DetailEmployees; }
            set
            {
                _DetailEmployees = value; this.OnPropertyChanged("DetailEmployees");


            }
        }
        #endregion

        private IEnumerable<z_PaymentMethod> _paymentmethord;
        public IEnumerable<z_PaymentMethod> paymentmethord
        {
            get { return _paymentmethord; }
            set { _paymentmethord = value; this.OnPropertyChanged("paymentmethord"); }
        }

        private z_PaymentMethod _CurrentPaymetMethord;
        public z_PaymentMethod CurrentPaymetMethord
        {
            get { return _CurrentPaymetMethord; }
            set { _CurrentPaymetMethord = value; }
        }

        private IEnumerable<z_CompanyBranches> _CompanyBraches;
        public IEnumerable<z_CompanyBranches> CompanyBraches
        {
            get { return _CompanyBraches; }
            set { _CompanyBraches = value; this.OnPropertyChanged("CompanyBraches"); }
        }

        private z_CompanyBranches _CurretCompanyBeanch;
        public z_CompanyBranches CurretCompanyBeanch
        {
            get { return _CurretCompanyBeanch; }
            set { _CurretCompanyBeanch = value; this.OnPropertyChanged("CurretCompanyBeanch"); }
        }

        private IEnumerable<z_CompanyBranches> _CompanyBranch;
        public IEnumerable<z_CompanyBranches> CompanyBranch
        {
            get { return _CompanyBranch; }
            set { _CompanyBranch = value; this.OnPropertyChanged("CompanyBranch"); }
        }

        private z_CompanyBranches _CurretCompanyBranch;
        public z_CompanyBranches CurretCompanyBranch
        {
            get { return _CurretCompanyBranch; }
            set { _CurretCompanyBranch = value; this.OnPropertyChanged("CurretCompanyBranch"); }
        }

        #endregion Properties

        #region Get Data From Database Using WCF Web Service

        #region Employee Details from Service
        private void refreshEmployees()
        {
            this.serviceClient.GetAllEmployeeDetailCompleted += (s, e) =>
            {
                this.AllEmployees = e.Result.Where(c => c.isdelete == false);
                this.AllEmployeesSorted = AllEmployees;
            };
            this.serviceClient.GetAllEmployeeDetailAsync();
        }
        #endregion Employee Details from Service

        #region Get Genders From Service

        private void refreshGenders()
        {
            try
            {
                this.serviceClient.getGendersCompleted += (s, e) =>
              {
                  this.Genders = e.Result;
              };
                this.serviceClient.getGendersAsync();
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #region Get Cities From Service

        private void refreshCity()
        {
            this.serviceClient.GetCitiesCompleted += (s, e) =>
            {
                this.Citys = e.Result.Where(c => c.isdelete == false);
            };
            this.serviceClient.GetCitiesAsync();
        }

        #endregion

        #region Get Towns From Service

        private void refreshTowns()
        {
            try
            {
                this.serviceClient.GetTownDetailsCompleted += (s, e) =>
                  {
                      if (CurrentCity != null)
                      {
                          this.Towns = e.Result.Where(z => z.city_id.Equals(CurrentCity.city_id) && z.isdelete == false);
                      }
                      else
                      {
                          this.Towns = e.Result;
                      }
                  };
                this.serviceClient.GetTownDetailsAsync();
            }
            catch (Exception)
            {
                clsMessages.setMessage("Towns Cannot Be Load Please Refresh Again !");
            }
        }

        #endregion

        #region Get Civil Status From Service

        private void refreshCivil()
        {
            this.serviceClient.GetCivilStatusCompleted += (s, e) =>
            {
                this.SivelStates = e.Result;
            };
            this.serviceClient.GetCivilStatusAsync();
        }

        #endregion

        #region Get Department From Service

        private void refreshDepartment()
        {
            this.serviceClient.GetDepartmentsCompleted += (s, e) =>
            {
                this.Departments = e.Result.Where(c => c.isdelete == false);
            };
            this.serviceClient.GetDepartmentsAsync();
        }

        #endregion

        #region Get Designation From Service

        private void refreshDesignation()
        {
            //Designation = serviceClient.GetDesignations();
            this.serviceClient.GetDesignationsCompleted += (s, e) =>
            {
                this.Designation = e.Result.Where(c => c.isdelete == false);
            };
            this.serviceClient.GetDesignationsAsync();
        }

        #endregion

        #region Get Section From Service

        private void refreshSection()
        {
            try
            {
                //List<z_Section> tempSections = this.serviceClient.GetSections().ToList();

                //if (CurrentDepartment != null)
                //{
                //    this.Sections = tempSections.Where(a => a.department_id.Equals(CurrentDepartment.department_id) && a.isdelete == false);
                //    // this.Sections = e.Result;
                //}
                //else
                //{
                //    this.Sections = tempSections;
                //}
                this.serviceClient.GetSectionsCompleted += (s, e) =>
                {
                    if (CurrentDepartment != null)
                    {
                        this.Sections = e.Result.Where(a => a.department_id.Equals(CurrentDepartment.department_id) && a.isdelete == false);
                        // this.Sections = e.Result;
                    }
                    else
                    {
                        this.Sections = e.Result.Where(c => c.isdelete == false); ;
                    }
                };
                this.serviceClient.GetSectionsAsync();
            }
            catch (Exception)
            {
            }

        }

        #endregion

        #region Get Grade From Service
        private void refreshGrade()
        {
            try
            {
                this.serviceClient.GetGradeCompleted += (s, e) =>
                 {
                     this.Grades = e.Result.Where(c => c.isdelete == false);
                 };
                this.serviceClient.GetGradeAsync();
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region Titles from Service
        private void refreshTitle()
        {

            this.serviceClient.GetTitleCompleted += (s, e) =>
            {
                this.Title = e.Result;
            };
            this.serviceClient.GetTitleAsync();

        }
        #endregion Titles from Service

        #region Religions from Service
        private void refreshReligion()
        {
            this.serviceClient.GetReligenCompleted += (s, e) =>
            {
                this.Religen = e.Result.Where(c => c.isdelete == false);
            };
            this.serviceClient.GetReligenAsync();
        }
        #endregion Religions from Service

        #region Company Branches from Service
        private void refreshCompanyBranch()
        {
            this.serviceClient.GetCompanyBranchesCompleted += (s, e) =>
            {
                this.CompanyBranch = e.Result.Where(z => z.isdelete == false);
            };
            this.serviceClient.GetCompanyBranchesAsync();
        }
        #endregion Company Branches from Service

        #region Payment Methods from Service
        private void refreshPaymentMethod()
        {
            this.serviceClient.GetPaymentMethodsCompleted += (s, e) =>
            {
                this.paymentmethord = e.Result;
            };
            this.serviceClient.GetPaymentMethodsAsync();
        }
        #endregion Payment Methods from Service

        #region Epf Status from Service
        void refreshEpfStatus()
        {
            serviceClient.GetMemberStatusCompleted += (s, e) =>
            {
                MemberStaus = e.Result;
            };
            serviceClient.GetMemberStatusAsync();
        }
        #endregion Epf Status from Service

        void refresh()
        {
            refreshSection();
            refreshGenders();
            refreshTitle();
            refreshCity();
            refreshDepartment();
            refreshDesignation();
            refreshGrade();
            refreshCivil();
            refreshTowns();
            refreshReligion();
            refreshPaymentMethod();
            refreshCompanyBranch();
        }

        #endregion

        #region Button Command

        #region New Button Command
        public ICommand NewButton
        {
            get
            {
                return new RelayCommand(New, newCanExecute);
            }
        }
        #endregion

        #region New Button Can Execute
        private bool newCanExecute()
        {
            return true;

        }
        #endregion

        #region Save Button Command
        public ICommand SaveButton
        {
            get
            {
                return new RelayCommand(Save, saveCanExecute);
            }
        }
        #endregion

        #region Save Button Can Execute
        private bool saveCanExecute()
        {

            if (CurrentEmployee != null)
            {
                if (this.CurrentEmployee.first_name == null || this.CurrentEmployee.first_name.ToString() == String.Empty)
                    return false;
                if (this.CurrentEmployee.emp_id == null)
                    return false;
                if (this.CurrentEmployee.employee_id == null)
                    return false;
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Delete Button Command
        public ICommand DeleteButton
        {
            get
            {
                return new RelayCommand(delete, deleteCanExecute);
            }
        }


        #endregion

        #region Delete Button Can Exicute

        private bool deleteCanExecute()
        {
            if (CurrentEmployee != null)
            {
                if (this.CurrentEmployee.employee_id != null)
                {
                    return this.CurrentEmployee.employee_id != null;
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #endregion

        #region User Defined Methods

        #region New Method

        public void New()
        {
            if (clsSecurity.GetPermissionForView(clsConfig.GetViewModelId(Viewmodels.Employee), clsSecurity.loggedUser.user_id))
            {
                Name = null;
                ImagePath = null;
                CurrentEmployee = null;

                CurrentEmployee = new EmployeeSumarryView();
                CurrentEmployee.employee_id = Guid.NewGuid();
                CurrentEmployee.city_id = Guid.Empty;
                CurrentEmployee.town_id = Guid.Empty;
                CurrentEmployee.department_id = Guid.Empty;
                CurrentEmployee.designation_id = Guid.Empty;
                CurrentEmployee.section_id = Guid.Empty;
                CurrentEmployee.grade_id = Guid.Empty;
                CurrentEmployee.gender_id = Guid.Empty;
                CurrentEmployee.civil_status_id = Guid.Empty;
                CurrentEmployee.branch_id = Guid.Empty;
                CurrentEmployee.payment_methord_id = Guid.Empty;
                CurrentEmployee.religen_id = Guid.Empty;

                if (CurrentCivilStatus != null)
                    CurrentCivilStatus.civi_status_id = Guid.Empty;

                CurrentEmployee.first_name = null;
                CurrentEmployee.surname = null;

                CurrentCivilStatus = new z_CivilState();

            }
            else
            {
                clsMessages.setMessage(Properties.Resources.NoPermissionForView);
            }
        }

        #endregion

        #region Save Method

        public void Save()
        {
            bool isUpdate = false;
            bool isNewSalary = false;
            decimal oldsalary = 0;

            mas_Employee newEmp = new mas_Employee();
            newEmp.employee_id = CurrentEmployee.employee_id;
            newEmp.emp_id = CurrentEmployee.emp_id;
            newEmp.etf_no = CurrentEmployee.etf_no;
            newEmp.epf_no = CurrentEmployee.epf_no;
            newEmp.initials = CurrentEmployee.initials;
            newEmp.first_name = CurrentEmployee.first_name;
            newEmp.second_name = CurrentEmployee.second_name;
            newEmp.surname = CurrentEmployee.surname;
            newEmp.address_01 = CurrentEmployee.address_01;
            newEmp.address_02 = CurrentEmployee.address_02;
            newEmp.address_03 = CurrentEmployee.address_03;
            newEmp.emg_contact = CurrentEmployee.emg_contact;
            newEmp.title_id = CurrentEmployee.title_id;
            newEmp.office_email = CurrentEmployee.office_email;
            newEmp.office_mobile = CurrentEmployee.office_mobile;

            //newEmp.image = path + CurrentEmployee.employee_id + ".Jpeg";
            newEmp.image = EmployeeImagePath;
            newEmp.town_id = CurrentEmployee.town_id;
            newEmp.city_id = CurrentEmployee.city_id;
            newEmp.gender_id = CurrentEmployee.gender_id;
            newEmp.birthday = CurrentEmployee.birthday;
            newEmp.nic = CurrentEmployee.nic;
            newEmp.civil_status_id = CurrentEmployee.civil_status_id;
            newEmp.telephone = CurrentEmployee.telephone;
            newEmp.mobile = CurrentEmployee.mobile;
            newEmp.email = CurrentEmployee.email;
            newEmp.religen_id = CurrentEmployee.religen_id;
            if(CurrentCivilStatus!=null)
            newEmp.civil_status_id = CurrentCivilStatus.civi_status_id;
            newEmp.isdelete = false;

            dtl_Employee newDaatel = new dtl_Employee();
            newDaatel.employee_id = CurrentEmployee.employee_id;
            newDaatel.department_id = (Guid)CurrentEmployee.department_id;
            newDaatel.designation_id = (Guid)CurrentEmployee.designation_id;
            newDaatel.grade_id = CurrentEmployee.grade_id;
            newDaatel.section_id = CurrentEmployee.section_id;
            newDaatel.join_date = CurrentEmployee.join_date;
            newDaatel.basic_salary = CurrentEmployee.basic_salary;
            newDaatel.prmernant_active_date = CurrentEmployee.prmernant_active_date;
            newDaatel.isETF_applicable = CurrentEmployee.isETF_applicable;
            newDaatel.isOT_applicable = CurrentEmployee.isOT_applicable;
            newDaatel.isEPF_applicable = CurrentEmployee.isEPF_applicable;
            newDaatel.isActive = CurrentEmployee.isActive;
            newDaatel.payment_methord_id = CurrentEmployee.payment_methord_id;
            newDaatel.branch_id = CurrentEmployee.branch_id;
            newDaatel.resign_date = CurrentEmployee.resign_date;
            newDaatel.auto_ot = CurrentEmployee.auto_ot;

            if (CurrentEmployee.resign_date != null)
                newDaatel.isActive = false;
            else
                newDaatel.isActive = CurrentEmployee.isActive;

            newDaatel.delete_datetime = System.DateTime.Now;
            newDaatel.delete_user_id = Guid.Empty;
            newDaatel.isdelete = false;
            newDaatel.mas_Employee = newEmp;
            newEmp.dtl_Employee = newDaatel;

            // IEnumerable<dtl_Employee> alldetailemployees = this.serviceClient.GetDetailEmployees(CurrentEmployeeDetail.employee_id);

            IEnumerable<EmployeeSumarryView> alldetailemployees = serviceClient.GetAllEmployeeDetail();

            //refreshEmployees();

            //allEmp = serviceClient.GetEmployees();

            foreach (EmployeeSumarryView emp in alldetailemployees)
            {
                if (emp.employee_id == newEmp.employee_id)
                {
                    isUpdate = true;
                    break;
                }
            }

            if (newDaatel != null)
            {
                if (isUpdate)
                {
                    foreach (EmployeeSumarryView employee in AllEmployees)//alldetailemployees)
                    {
                        if (employee.basic_salary != CurrentEmployee.basic_salary && employee.employee_id == CurrentEmployee.employee_id)
                        {
                            isNewSalary = true;
                            if (employee.basic_salary == null)
                            {
                                oldsalary = 0;
                            }
                            else
                            {
                                oldsalary = (decimal)employee.basic_salary;
                            }
                        }
                    }
                    if (isNewSalary == true)
                    {
                        dtl_historyBasicSalary basicsalary = new dtl_historyBasicSalary();
                        basicsalary.employee_id = CurrentEmployee.employee_id;
                        basicsalary.old_salary = oldsalary;
                        basicsalary.new_salary = CurrentEmployee.basic_salary;
                        basicsalary.affective_date = System.DateTime.Now;
                        basicsalary.update_user_id = clsSecurity.loggedUser.user_id;
                        basicsalary.isactive = true;
                        bool a = serviceClient.UpdateEmployeeActive(basicsalary);
                        bool b = serviceClient.UpdateEmployeeBasicSalary(basicsalary);
                    }

                    newDaatel.modified_datetime = System.DateTime.Now;
                    newDaatel.modified_user_id = clsSecurity.loggedUser.user_id;

                    if (clsSecurity.GetPermissionForUpdate(clsConfig.GetViewModelId(Viewmodels.Employee), clsSecurity.loggedUser.user_id))
                    {
                        if (serviceClient.UpdateEmployee(newEmp) && SaveMemberStatus())
                        {
                            clsMessages.setMessage(Properties.Resources.UpdateSucess);
                            //reafreshEmployeeDetail();
                            //refreshEmplooyeeBlood();
                            refreshEmployees();
                            refreshEpfStatus();

                            #region Mihiri_Report Print

                            refreshConfirmationDetail();

                            //MessageBox.Show(Convert.ToString(OldConfirmDetails.Count()));

                            if (OldConfirmDetails != null && OldConfirmDetails.Where(c => c.employee_id == newEmp.employee_id).Count() > 0)
                            {
                                if (newDaatel.prmernant_active_date != null)
                                {
                                    MessageBoxResult dr = MessageBox.Show("Permenent date changed.Do you want to print a letter for Employee?", "Employee Updated", MessageBoxButton.YesNo, MessageBoxImage.None);
                                    if (dr == MessageBoxResult.Yes)
                                    {
                                        // \Reports\Documents\HR_Report\ConfirmationDateExtendReport
                                        ReportPrint print = new ReportPrint("\\Reports\\Documents\\HR_Report\\ConfirmationDateExtendReport");
                                        print.setParameterValue("@id", newEmp.employee_id.ToString());
                                        print.PrintReportWithReportViewer();
                                    }
                                }
                            }

                            #endregion

                            #region Image Save
                            if (Image != null)
                                SaveImage();
                            #endregion
                        }
                        else
                        {
                            clsMessages.setMessage(Properties.Resources.UpdateFail);
                        }
                        refreshEmployees();
                        //reafreshEmployeeDetail();
                    }
                    else
                    {
                        clsMessages.setMessage(Properties.Resources.NoPermissionForUpdate);
                    }
                }
                else
                {
                    if (clsSecurity.GetPermissionForSave(clsConfig.GetViewModelId(Viewmodels.Employee), clsSecurity.loggedUser.user_id))
                    {
                        newDaatel.save_datetime = System.DateTime.Now;
                        newDaatel.save_user_id = clsSecurity.loggedUser.user_id;
                        newDaatel.modified_datetime = System.DateTime.Now;
                        newDaatel.modified_user_id = clsSecurity.loggedUser.user_id;
                        newDaatel.delete_datetime = System.DateTime.Now;
                        newDaatel.delete_user_id = clsSecurity.loggedUser.user_id;

                        if (serviceClient.SaveEmployee(newEmp) && SaveMemberStatus())
                        {
                            clsMessages.setMessage(Properties.Resources.SaveSucess);
                            //reafreshMasEmployee();
                            //reafreshEmployeeDetail();
                            //refreshEmplooyeeBlood();
                            refreshEmployees();
                            refreshEpfStatus();

                            #region Image Save
                            if (Image != null)
                                SaveImage();
                            #endregion
                        }
                        else
                        {
                            clsMessages.setMessage(Properties.Resources.SaveFail);
                        }
                    }
                    else
                    {
                        clsMessages.setMessage(Properties.Resources.NoPermissionForSave);
                    }
                }
            }
            else
            {
                MessageBox.Show("Required fields cannot be empty.");
            }
        }

        #endregion

        #region Delete Methord
        private void delete()
        {
            if (clsSecurity.GetPermissionForSave(clsConfig.GetViewModelId(Viewmodels.Employee), clsSecurity.loggedUser.user_id))
            {
                dtl_Employee delEmp = new dtl_Employee();
                delEmp.employee_id = CurrentEmployee.employee_id;
                delEmp.delete_datetime = System.DateTime.Now;
                delEmp.delete_user_id = clsSecurity.loggedUser.user_id;
                MessageBoxResult Result = new MessageBoxResult();

                Result = MessageBox.Show("Do You Want to Delete This Record ?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (Result == MessageBoxResult.Yes)
                {
                    if (serviceClient.DeleteEmployee(delEmp))
                    {
                        clsMessages.setMessage(Properties.Resources.DeleteSucess);
                        refreshEmployees();
                        //reafreshEmployeeDetail();
                        //reafreshMasEmployee();
                    }
                    else
                    {
                        clsMessages.setMessage(Properties.Resources.DeleteFail);
                    }
                }
            }
            else
            {
                clsMessages.setMessage(Properties.Resources.NoPermissionForSave);
            }
        }
        #endregion

        #endregion User Defined Methods

        #region Epf Status

        private List<string> _ePFList = new List<string>();
        public List<string> EPFList
        {
            get { return _ePFList; }
            set { _ePFList = value; OnPropertyChanged("EPFList"); }
        }

        private string _currentEPFList;
        public string CurrentEPFList
        {
            get { return _currentEPFList; }
            set { _currentEPFList = value; OnPropertyChanged("CurrentEPFList"); }
        }

        private IEnumerable<dtl_member_status> memberStaus;
        public IEnumerable<dtl_member_status> MemberStaus
        {
            get { return memberStaus; }
            set { memberStaus = value; OnPropertyChanged("MemberStaus"); }
        }

        private bool SaveMemberStatus()
        {
            if (CurrentEmployee != null && (String.IsNullOrEmpty(CurrentEPFList)) == false)
                try
                {
                    bool update = false;

                    dtl_member_status member = new dtl_member_status();
                    if (CurrentEmployee != null)
                        member.employee_id = CurrentEmployee.employee_id;
                    if (CurrentEPFList.Equals("Extg."))
                        member.member_status = "E";
                    else if (CurrentEPFList.Equals("New"))
                        member.member_status = "N";
                    else if (CurrentEPFList.Equals("Vacated"))
                        member.member_status = "V";
                    update = MemberStaus.Where(c => c.employee_id == CurrentEmployee.employee_id).Count() == 1;
                    if (update)
                        if (serviceClient.UpdateMemberStatus(member))
                            return true;
                        else
                            return false;
                    else
                        if (serviceClient.SaveMemberSatus(member))
                            return true;
                        else
                            if (serviceClient.UpdateMemberStatus(member))
                                return true;
                            else
                                return false;
                }
                catch (Exception)
                {
                    return false;
                }
            return true;

        }

        #endregion Epf Status

        #region Search Function

        private List<string> _SearchItem;
        public List<string> SearchItem
        {
            get { return _SearchItem; }
            set { _SearchItem = value; this.OnPropertyChanged("SearchItem"); }
        }

        private List<string> _SelectionItems = new List<string>();
        public List<string> SelectionItems
        {
            get { return this._SelectionItems; }
            set { this._SelectionItems = value; this.OnPropertyChanged("SelectionItems"); }
        }

        private string _SearchSelectedItem;
        public string SearchSelectedItem
        {
            get { return this._SearchSelectedItem; }
            set { this._SearchSelectedItem = value; OnPropertyChanged("SearchSelectedItem"); }
        }

        private string _Search;
        public string Search
        {
            get
            {
                return this._Search;
            }
            set
            {
                this._Search = value;
                this.OnPropertyChanged("Search");

                if (this._Search == "")
                {
                    refreshSearch();
                }
                else
                {
                    searchTextChanged();
                }
            }
        }

        public List<string> SerchItem = new List<string>();

        public void searchTextChanged()
        {
            if (SearchSelectedItem == "Employee No")
            {
                AllEmployeesSorted = AllEmployees.Where(e => e.emp_id.ToUpper().Contains(Search.ToUpper())).ToList();
            }
            if (SearchSelectedItem == "First Name")
            {
                AllEmployeesSorted = AllEmployees.Where(e => e.first_name.ToUpper().Contains(Search.ToUpper())).ToList();
            }
            if (SearchSelectedItem == "Last Name")
            {
                AllEmployeesSorted = AllEmployees.Where(e => e.second_name.ToUpper().Contains(Search.ToUpper())).ToList();
            }
        }

        public void refreshSearch()
        {
            this.AllEmployeesSorted = this.AllEmployees;
        }

        #endregion Search Function

        #region Busy Box

        private bool _isBusy;
        public bool isBusy
        {
            get { return _isBusy; }
            set { _isBusy = value; this.OnPropertyChanged("isBusy"); }
        }

        private Visibility _busyGridVisibility;
        public Visibility busyGridVisibility
        {
            get { return _busyGridVisibility; }
            set { _busyGridVisibility = value; this.OnPropertyChanged("busyGridVisibility"); }
        }

        void after()
        {
            if (T.IsCompleted)
            {
                isBusy = false;
                this.New();
                busyGridVisibility = Visibility.Collapsed;
            }
        }

        #endregion Busy Box

        #region Additional UserContol Loader

        #region AddMethods

        void CityAdd()
        {
            City userControl = new City();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshCity();
        }

        void TownAdd()
        {
            TownMasterUserControl userControl = new TownMasterUserControl();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshCity();

        }

        void DepartmentAdd()
        {
            DepartmentsUserControl userControl = new DepartmentsUserControl();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshDepartment();
        }

        void DesignationAdd()
        {
            Designation userControl = new Designation();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshDesignation();
        }

        void SectionAdd()
        {
            SectionsUserControl userControl = new SectionsUserControl();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshSection();
        }

        void GradeAdd()
        {
            EmployeeGrade userControl = new EmployeeGrade();
            UserControlWindow uC = new UserControlWindow(userControl);
            uC.Height = userControl.Height;
            uC.Width = userControl.Width;
            uC.ShowDialog();
            refreshGrade();
        }

        #endregion

        public ICommand CityAddButton
        {
            get
            {
                return new RelayCommand(CityAdd);
            }
        }

        public ICommand TownAddButton
        {
            get
            {
                return new RelayCommand(TownAdd);
            }
        }

        public ICommand DepartmentAddButton
        {
            get
            {
                return new RelayCommand(DepartmentAdd);
            }
        }

        public ICommand DesignationAddButton
        {
            get
            {
                return new RelayCommand(DesignationAdd);
            }
        }

        public ICommand SectionAddButton
        {
            get
            {
                return new RelayCommand(SectionAdd);
            }
        }

        public ICommand GradeAddButton
        {
            get
            {
                return new RelayCommand(GradeAdd);
            }
        }

        #endregion Additional UserContol Loader

        #region Error

        #region Validation Properties
        private string _EmployeeNo;
        public string EmployeeNo
        {
            get { return _EmployeeNo; }
            set
            {
                _EmployeeNo = value; OnPropertyChanged("EmployeeNo");
                if (CurrentEmployee != null)
                    CurrentEmployee.emp_id = EmployeeNo;
            }
        }

        private string _FirstName;
        public string FirstName
        {
            get { return _FirstName; }
            set
            {
                _FirstName = value; OnPropertyChanged("FirstName");
                if (CurrentEmployee != null)
                    CurrentEmployee.first_name = FirstName;
            }
        }

        private string _Surname;
        public string Surname
        {
            get { return _Surname; }
            set
            {
                _Surname = value; OnPropertyChanged("Surname");
                if (CurrentEmployee != null)
                    CurrentEmployee.surname = Surname;
            }
        }

        private string _NIC;
        public string NIC
        {
            get { return _NIC; }
            set
            {
                _NIC = value; OnPropertyChanged("NIC");
                if (CurrentEmployee != null)
                    CurrentEmployee.nic = NIC;
            }
        }

        private DateTime? _Birthday;
        public DateTime? Birthday
        {
            get { return _Birthday; }
            set
            {
                _Birthday = value; OnPropertyChanged("Birthday");
                if (CurrentEmployee != null)
                {
                    CurrentEmployee.birthday = Birthday;
                }
                //CurrentEmployeeDetail.birthday = Birthday;
            }

        }

        private string _Address;
        public string Address
        {
            get { return _Address; }
            set
            {
                _Address = value; OnPropertyChanged("Address");
                if (CurrentEmployee != null)
                    CurrentEmployee.address_01 = Address;

            }
        }

        private string _Mobile;
        public string Mobile
        {
            get { return _Mobile; }
            set
            {
                _Mobile = value; OnPropertyChanged("Mobile");
                if (CurrentEmployee != null)
                    CurrentEmployee.mobile = Mobile;

            }
        }
        #endregion

        #region Error Interface
        public string Error
        {
            get { throw new NotImplementedException(); }
        }

        string IDataErrorInfo.this[string PropertyName]
        {
            get
            {
                return getValidationError(PropertyName);
            }
        }
        #endregion

        private string getValidationError(string PropertyName)
        {

            String error = null;
            switch (PropertyName)
            {
                case "EmployeeNo":
                    error = String.IsNullOrWhiteSpace(EmployeeNo) ? "Cannot Be Empty" : null;
                    break;
                case "FirstName":
                    error = String.IsNullOrWhiteSpace(FirstName) ? "Cannot Be Empty" : null;
                    break;
                case "Surname":
                    error = String.IsNullOrWhiteSpace(Surname) ? "Cannot Be Empty" : null;
                    break;
                case "NIC":
                    error = String.IsNullOrWhiteSpace(NIC) ? "Cannot Be Empty" : null;
                    break;
                //case "Birthday":
                //    error = CurrentEmployeeDetail.birthday == null ? "Cannot Be Empty" : null;
                //    break;
                case "Address":
                    error = String.IsNullOrWhiteSpace(Address) ? "Cannot Be Empty" : null;
                    break;

            }
            return error;
        }

        #endregion

        #region Act
        public ICommand ActButton
        {
            get { return new RelayCommand(Act); }
        }
        void Act()
        {
            bool isAct = false;
            IEnumerable<EmployeeSumarryView> alldetailemployees = serviceClient.GetAllEmployeeDetail();
            foreach (EmployeeSumarryView emp in alldetailemployees)
            {
                if (emp.employee_id == CurrentEmployee.employee_id)
                {
                    isAct = true;
                    break;
                }
            }

            if (isAct)
            {
                if (CurrentEmployee.basic_salary != null && CurrentEmployee.basic_salary > 0)
                {
                    EmployeeActWindow window = new EmployeeActWindow(CurrentEmployee.employee_id,(decimal)CurrentEmployee.basic_salary);
                    window.Show();
                }
                else
                    clsMessages.setMessage("Basic Salary should be greater than 0");
            }
            else
                clsMessages.setMessage("Please select a saved employee");
        }
        #endregion

        #region Medical
        public ICommand MedicalButton 
        {
            get { return new RelayCommand(Medical); }
        }
        void Medical() 
        {
            bool MedCanLoad = false;
            IEnumerable<EmployeeSumarryView> alldetailemployees = serviceClient.GetAllEmployeeDetail();
            foreach (EmployeeSumarryView emp in alldetailemployees)
            {
                if (emp.employee_id == CurrentEmployee.employee_id)
                {
                    MedCanLoad = true;
                    break;
                }
            }
            if (MedCanLoad) 
            {
                MedicalDetailsUserControl userControl = new MedicalDetailsUserControl(CurrentEmployee);
                UserControlWindow uC = new UserControlWindow(userControl);
                uC.Height = userControl.Height;
                uC.Width = userControl.Width;
                uC.ShowDialog();
            }
            else
                clsMessages.setMessage("Please select a saved employee");
        }
        #endregion

        #region Scale
        private double _scaleSize;

        public double ScaleSize
        {
            get { return _scaleSize; }
            set { _scaleSize = value; OnPropertyChanged("ScaleSize"); }
        }

        public void scale()
        {
            ScaleSize = 1;
            double h = System.Windows.SystemParameters.PrimaryScreenHeight;
            double w = System.Windows.SystemParameters.PrimaryScreenWidth;
            //  double h= System.Windows.SystemParameters.PrimaryScreenHeight;
            if (h * w == 1366 * 768)
                ScaleSize = 0.90;
            // ScaleSize = 0.75;
            if (w * h == 1280 * 768)
                ScaleSize = 0.90;
            if (w * h == 1024 * 768)
                ScaleSize = 1.2;
        } 
        #endregion

        #region Image

        private string _employeeImagePath;
        public string EmployeeImagePath
        {
            get { return _employeeImagePath; }
            set { _employeeImagePath = value; OnPropertyChanged("EmployeeImagePath"); }
        }

        private string _imagePath;
        public string ImagePath
        {
            get { return _imagePath; }
            set { _imagePath = value; OnPropertyChanged("ImagePath"); }
        }

        private Image _Image;
        public Image Image
        {
            get { return _Image; }
            set { _Image = value; OnPropertyChanged("Image"); }
        }
        public ICommand ImageDelete
        {
            get { return new RelayCommand(deleteImage); }
        }

        public ICommand ImageButton
        {
            get { return new RelayCommand(browseImage); }
        }

        void SaveImage()
        {
            string DirectoryPath = path + "\\" + CurrentEmployee.employee_id + "\\";
            if (Directory.Exists(DirectoryPath) == false)
            {
                Directory.CreateDirectory(DirectoryPath);
                Image.Save(EmployeeImagePath, ImageFormat.Jpeg);
            }
            else
                if (File.Exists(EmployeeImagePath))
                {
                    try
                    {
                        Image.Save(EmployeeImagePath, ImageFormat.Jpeg);
                    }
                    catch (Exception)
                    {

                        clsMessages.setMessage("Please Close the Application and Restart to Set the Image");
                    }
                }
                else
                    Image.Save(EmployeeImagePath, ImageFormat.Jpeg);

            ImagePath = EmployeeImagePath;
        }

        void deleteImage()
        {
            EmployeeImagePath = null;
            ImagePath = null;
            clsMessages.setMessage("Now Press Save button to Complete the Action");
        }

        void browseImage()
        {
            System.Windows.Forms.OpenFileDialog open = new System.Windows.Forms.OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    Image = new Bitmap(open.FileName);
                    ImagePath = open.FileName;
                    //string imagename = open.SafeFileName;
                    ImageNameandPath();
                }
                catch (Exception)
                {
                }
            }
        }

        void ImageNameandPath()
        {
            Guid FileName = new Guid();
            FileName = Guid.NewGuid();
            EmployeeImagePath = path + CurrentEmployee.employee_id + "\\" + FileName + ".Jpeg";
        }

        #endregion

        #region Documents

        private List<string> _PathList;

        public List<string> PathList
        {
            get { return _PathList; }
            set { _PathList = value; OnPropertyChanged("PathList"); }
        }

        private IEnumerable<FileInfo> _FilePath;

        public IEnumerable<FileInfo> FilePath
        {
            get { return _FilePath; }
            set { _FilePath = value; OnPropertyChanged("FilePath"); }
        }

        private FileInfo _FileName;

        public FileInfo FileName
        {
            get { return _FileName; }
            set { _FileName = value; OnPropertyChanged("FileName"); }
        }

        public ICommand Browse
        {
            get { return new RelayCommand(openFile); }
        }

        public ICommand OpenADoc
        {
            get { return new RelayCommand(OpenADocument); }
        }

        void OpenADocument()
        {

            try
            {
                System.Diagnostics.Process.Start("explorer.exe", FileName.FullName);
            }
            catch (Exception)
            {
                clsMessages.setMessage("No file selected");
            }
        }

        void loadGrid()
        {

            if (Directory.Exists(path + "Documents\\" + CurrentEmployee.employee_id + "\\") == true)
            {
                FilePath = new DirectoryInfo(path + "Documents\\" + CurrentEmployee.employee_id + "\\").GetFiles();
            }
        }

        void openFile()
        {
            if (CurrentEmployee != null && CurrentEmployee.employee_id != null)
            {
                string fileName = "";



                System.Windows.Forms.OpenFileDialog open = new System.Windows.Forms.OpenFileDialog();
                open.Filter = "pdf files (*.pdf) |*.pdf;";
                if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {


                    string[] filename = (open.FileName).Split('\\');

                    foreach (var item in filename)
                    {
                        if (item.Contains(".pdf"))
                        {
                            fileName = item;
                            break;
                        }
                    }

                    if (Directory.Exists(path + "Documents\\" + CurrentEmployee.employee_id + "\\") == false)
                    {
                        Directory.CreateDirectory(path + "Documents\\" + CurrentEmployee.employee_id + "\\");

                        File.Copy(open.FileName, path + "Documents\\" + CurrentEmployee.employee_id + "\\" + fileName);
                    }
                    else
                    {
                        try
                        {
                            File.Copy(open.FileName, path + "Documents\\" + CurrentEmployee.employee_id + "\\" + fileName, true);
                        }
                        catch (Exception)
                        {

                        }
                    }
                }

                loadGrid();
            }
        }

        #endregion

        #region Mihiri

        #region Extend Confirmation details

        #region Get data from service for confirmation

        private IEnumerable<OldConfirmationDate> _OldConfirmDetails;
        public IEnumerable<OldConfirmationDate> OldConfirmDetails
        {
            get { return _OldConfirmDetails; }
            set { _OldConfirmDetails = value; OnPropertyChanged("OldConfirmDetails"); }
        }

        #endregion

        #region Get Confirmation details

        private void refreshConfirmationDetail()
        {
            this.OldConfirmDetails = serviceClient.GetConfirmationDetails();
        }

        #endregion

        #endregion

        #endregion

    }
}

